import json
import boto3


def lambda_handler(event, context):
    

    Sender = "Andrzej Kwiecien <kwiecien_andrzej@interia.pl>"
    Receiver = "andrzej.kwiecien@here.com"
    # ConfigurationSet = "ConfigSet"
    AwsRegion = "eu-west-1"
    Subject = "Subject"
    BodyText = "This email was send from Amazon SES Test"
    BodyHtml = """<html>
        <head></head>
        <body>
        <h1>Amazon SES Test (SDK for Python)</h1>
        <p>This email was sent with
            <a href='https://aws.amazon.com/ses/'>Amazon SES</a> using the
            <a href='https://aws.amazon.com/sdk-for-python/'>
            AWS SDK for Python (Boto)</a>.</p>
        </body>
        </html>
            """
    Charset = "UTF-8"
    
    client = boto3.client('ses', region_name=AwsRegion)

    response = client.send_email(
        Destination={
            'ToAddresses': [
                Receiver,
            ],
        },
        Message={
            'Body': {
                'Html': {
                    'Charset': Charset,
                    'Data': BodyHtml,
                },
                'Text': {
                    'Charset': Charset,
                    'Data': BodyText,
                },
            },
            'Subject': {
                'Charset': Charset,
                'Data': Subject,
            },
        },
        Source=Sender,
        # If you are not using a configuration set, comment or delete the
        # following line
        # ConfigurationSetName=ConfigurationSet,
    )

    return {
        "statusCode": 200,
        "body": json.dumps({
            "resource": "Lambda function",
            "trigger": "CloudWatch"
        }),
    }
